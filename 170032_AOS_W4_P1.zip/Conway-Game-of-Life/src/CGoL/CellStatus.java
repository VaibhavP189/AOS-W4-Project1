package CGoL;

public enum CellStatus {
	Dead,Alive;
}
